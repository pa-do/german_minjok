serviceId = "ncp:sms:kr:259241969530:german"
access_key = "MnYIs6OrJkEdFJcnsRm1"
secret_key = "h4Wl6coduavPADMRcnkGFIXz3XOl4G4J8gyT9Vmy"